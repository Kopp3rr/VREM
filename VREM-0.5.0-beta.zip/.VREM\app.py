"""VREM — Volumetric Radar Echo Map · Flask Backend"""
import os, json, math, re, tempfile, hashlib, random, contextlib, io, logging
from datetime import datetime, timedelta, timezone
from xml.etree import ElementTree
from flask import Flask, render_template, jsonify, request, Response
import urllib.parse, urllib.request, urllib.error

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _env_int(name, default, min_value=None, max_value=None):
    try:
        value = int(os.environ.get(name, default))
    except (TypeError, ValueError):
        value = default
    if min_value is not None:
        value = max(min_value, value)
    if max_value is not None:
        value = min(max_value, value)
    return value

def _env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}

app = Flask(__name__)
app.config.update(
    JSON_SORT_KEYS=False,
    MAX_CONTENT_LENGTH=16 * 1024 * 1024,
)

LEVEL2_BUCKET = os.environ.get("VREM_LEVEL2_BUCKET", "unidata-nexrad-level2")
LEVEL2_BASE_URL = f"https://{LEVEL2_BUCKET}.s3.amazonaws.com"
LEVEL2_CACHE_DIR = os.environ.get("VREM_CACHE_DIR", os.path.join(BASE_DIR, ".cache", "level2"))
SCAN_LOOKBACK_DAYS = _env_int("VREM_SCAN_LOOKBACK_DAYS", 3, 1, 14)
MAX_SCANS = _env_int("VREM_MAX_SCANS", 32, 1, 96)
MAX_LIVE_GATES = _env_int("VREM_MAX_LIVE_GATES", 65000, 1000, 250000)
MAX_CACHE_FILES = _env_int("VREM_MAX_CACHE_FILES", 96, 8, 512)
LIVE_REFRESH_SECONDS = _env_int("VREM_LIVE_REFRESH_SECONDS", 30, 10, 300)
LIVE_SCAN_CACHE_SECONDS = _env_int("VREM_LIVE_SCAN_CACHE_SECONDS", 12, 3, 60)
APP_HOST = os.environ.get("VREM_HOST", "127.0.0.1")
APP_PORT = _env_int("VREM_PORT", 5000, 1, 65535)
APP_DEBUG = _env_bool("VREM_DEBUG", False)
APP_THREADS = _env_int("VREM_THREADS", 8, 1, 32)
RUNTIME_SETTINGS = {
    "suppress_terminal_warnings": _env_bool("VREM_SUPPRESS_TERMINAL_WARNINGS", True),
    "parser_verbosity": os.environ.get("VREM_PARSER_VERBOSITY", "normal").strip().lower(),
}
EARTH_RADIUS_4_3_KM = 8494.6667
NWS_ALERTS_URL = "https://api.weather.gov/alerts/active"
ALERT_EVENTS = {
    "Tornado Warning",
    "Severe Thunderstorm Warning",
    "Flash Flood Warning",
    "Tornado Watch",
    "Severe Thunderstorm Watch",
}
PARSED_LEVEL2_CACHE = {}
LATEST_SCAN_CACHE = {}
ALERT_CACHE = {"timestamp": None, "payload": None}

def _apply_runtime_logging_settings():
    verbosity = RUNTIME_SETTINGS.get("parser_verbosity", "normal")
    suppress = bool(RUNTIME_SETTINGS.get("suppress_terminal_warnings", True))
    if suppress:
        level = logging.ERROR
    elif verbosity == "verbose":
        level = logging.DEBUG
    elif verbosity == "quiet":
        level = logging.ERROR
    else:
        level = logging.WARNING
    logging.getLogger("metpy.io.nexrad").setLevel(level)

_apply_runtime_logging_settings()

WSR88D = {
    "KABR":{"lat":45.456,"lon":-98.413,"name":"Aberdeen SD","state":"SD"},
    "KABX":{"lat":35.150,"lon":-106.824,"name":"Albuquerque NM","state":"NM"},
    "KAKQ":{"lat":36.984,"lon":-77.007,"name":"Norfolk/Richmond VA","state":"VA"},
    "KAMA":{"lat":35.233,"lon":-101.709,"name":"Amarillo TX","state":"TX"},
    "KAMX":{"lat":25.611,"lon":-80.413,"name":"Miami FL","state":"FL"},
    "KAPX":{"lat":44.907,"lon":-84.720,"name":"Gaylord MI","state":"MI"},
    "KARX":{"lat":43.823,"lon":-91.191,"name":"La Crosse WI","state":"WI"},
    "KATX":{"lat":48.194,"lon":-122.496,"name":"Seattle WA","state":"WA"},
    "KBBX":{"lat":39.496,"lon":-121.632,"name":"Beale AFB CA","state":"CA"},
    "KBGM":{"lat":42.200,"lon":-75.985,"name":"Binghamton NY","state":"NY"},
    "KBHX":{"lat":40.499,"lon":-124.292,"name":"Eureka CA","state":"CA"},
    "KBIS":{"lat":46.771,"lon":-100.760,"name":"Bismarck ND","state":"ND"},
    "KBLX":{"lat":45.854,"lon":-108.607,"name":"Billings MT","state":"MT"},
    "KBMX":{"lat":33.172,"lon":-86.770,"name":"Birmingham AL","state":"AL"},
    "KBOX":{"lat":41.956,"lon":-71.137,"name":"Boston MA","state":"MA"},
    "KBRO":{"lat":25.916,"lon":-97.419,"name":"Brownsville TX","state":"TX"},
    "KBUF":{"lat":42.949,"lon":-78.737,"name":"Buffalo NY","state":"NY"},
    "KBYX":{"lat":24.598,"lon":-81.703,"name":"Key West FL","state":"FL"},
    "KCAE":{"lat":33.949,"lon":-81.118,"name":"Columbia SC","state":"SC"},
    "KCBW":{"lat":46.039,"lon":-67.807,"name":"Caribou ME","state":"ME"},
    "KCBX":{"lat":43.491,"lon":-116.236,"name":"Boise ID","state":"ID"},
    "KCCX":{"lat":40.923,"lon":-78.004,"name":"State College PA","state":"PA"},
    "KCLE":{"lat":41.413,"lon":-81.860,"name":"Cleveland OH","state":"OH"},
    "KCLX":{"lat":32.656,"lon":-81.042,"name":"Charleston SC","state":"SC"},
    "KCRP":{"lat":27.784,"lon":-97.511,"name":"Corpus Christi TX","state":"TX"},
    "KCXX":{"lat":44.511,"lon":-73.166,"name":"Burlington VT","state":"VT"},
    "KCYS":{"lat":41.152,"lon":-104.806,"name":"Cheyenne WY","state":"WY"},
    "KDAX":{"lat":38.501,"lon":-121.678,"name":"Sacramento CA","state":"CA"},
    "KDDC":{"lat":37.721,"lon":-99.969,"name":"Dodge City KS","state":"KS"},
    "KDFX":{"lat":29.273,"lon":-100.281,"name":"Laughlin AFB TX","state":"TX"},
    "KDGX":{"lat":32.280,"lon":-89.984,"name":"Jackson MS","state":"MS"},
    "KDIX":{"lat":39.947,"lon":-74.411,"name":"Philadelphia PA","state":"PA"},
    "KDLH":{"lat":46.837,"lon":-92.210,"name":"Duluth MN","state":"MN"},
    "KDMX":{"lat":41.731,"lon":-93.723,"name":"Des Moines IA","state":"IA"},
    "KDOX":{"lat":38.826,"lon":-75.440,"name":"Dover AFB DE","state":"DE"},
    "KDTX":{"lat":42.700,"lon":-83.472,"name":"Detroit MI","state":"MI"},
    "KDVN":{"lat":41.612,"lon":-90.581,"name":"Davenport IA","state":"IA"},
    "KDYX":{"lat":32.539,"lon":-99.254,"name":"Dyess AFB TX","state":"TX"},
    "KEAX":{"lat":38.810,"lon":-94.264,"name":"Kansas City MO","state":"MO"},
    "KEMX":{"lat":31.894,"lon":-110.630,"name":"Tucson AZ","state":"AZ"},
    "KENX":{"lat":42.586,"lon":-74.064,"name":"Albany NY","state":"NY"},
    "KEOX":{"lat":31.461,"lon":-85.459,"name":"Fort Rucker AL","state":"AL"},
    "KEPZ":{"lat":31.873,"lon":-106.698,"name":"El Paso TX","state":"TX"},
    "KESX":{"lat":35.701,"lon":-114.891,"name":"Las Vegas NV","state":"NV"},
    "KEVX":{"lat":30.564,"lon":-85.921,"name":"Eglin AFB FL","state":"FL"},
    "KEWX":{"lat":29.704,"lon":-98.028,"name":"Austin/San Antonio TX","state":"TX"},
    "KEYX":{"lat":35.098,"lon":-117.561,"name":"Edwards AFB CA","state":"CA"},
    "KFCX":{"lat":37.024,"lon":-80.274,"name":"Roanoke VA","state":"VA"},
    "KFDR":{"lat":34.362,"lon":-98.976,"name":"Frederick OK","state":"OK"},
    "KFFC":{"lat":33.364,"lon":-84.566,"name":"Atlanta GA","state":"GA"},
    "KFSD":{"lat":43.588,"lon":-96.729,"name":"Sioux Falls SD","state":"SD"},
    "KFSX":{"lat":34.574,"lon":-111.198,"name":"Flagstaff AZ","state":"AZ"},
    "KFTG":{"lat":39.787,"lon":-104.546,"name":"Denver CO","state":"CO"},
    "KFWS":{"lat":32.573,"lon":-97.303,"name":"Dallas/Fort Worth TX","state":"TX"},
    "KGGW":{"lat":48.206,"lon":-106.625,"name":"Glasgow MT","state":"MT"},
    "KGJX":{"lat":39.062,"lon":-108.214,"name":"Grand Junction CO","state":"CO"},
    "KGLD":{"lat":39.367,"lon":-101.700,"name":"Goodland KS","state":"KS"},
    "KGRB":{"lat":44.499,"lon":-88.111,"name":"Green Bay WI","state":"WI"},
    "KGRK":{"lat":30.722,"lon":-97.383,"name":"Fort Hood TX","state":"TX"},
    "KGRR":{"lat":42.894,"lon":-85.545,"name":"Grand Rapids MI","state":"MI"},
    "KGSP":{"lat":34.883,"lon":-82.220,"name":"Greenville SC","state":"SC"},
    "KGWX":{"lat":33.897,"lon":-88.329,"name":"Columbus AFB MS","state":"MS"},
    "KGYX":{"lat":43.891,"lon":-70.257,"name":"Portland ME","state":"ME"},
    "KHDX":{"lat":33.077,"lon":-106.123,"name":"Holloman AFB NM","state":"NM"},
    "KHGX":{"lat":29.472,"lon":-95.079,"name":"Houston TX","state":"TX"},
    "KHNX":{"lat":36.314,"lon":-119.632,"name":"San Joaquin Valley CA","state":"CA"},
    "KHPX":{"lat":36.737,"lon":-87.285,"name":"Fort Campbell KY","state":"KY"},
    "KHTX":{"lat":34.931,"lon":-86.084,"name":"Huntsville AL","state":"AL"},
    "KICT":{"lat":37.654,"lon":-97.443,"name":"Wichita KS","state":"KS"},
    "KICX":{"lat":37.591,"lon":-112.862,"name":"Cedar City UT","state":"UT"},
    "KILN":{"lat":39.420,"lon":-83.822,"name":"Cincinnati OH","state":"OH"},
    "KILX":{"lat":40.151,"lon":-89.337,"name":"Lincoln IL","state":"IL"},
    "KIND":{"lat":39.708,"lon":-86.280,"name":"Indianapolis IN","state":"IN"},
    "KINX":{"lat":36.175,"lon":-95.564,"name":"Tulsa OK","state":"OK"},
    "KIWA":{"lat":33.289,"lon":-111.670,"name":"Phoenix AZ","state":"AZ"},
    "KIWX":{"lat":41.359,"lon":-85.700,"name":"Fort Wayne IN","state":"IN"},
    "KJAX":{"lat":30.485,"lon":-81.702,"name":"Jacksonville FL","state":"FL"},
    "KJGX":{"lat":32.675,"lon":-83.351,"name":"Robins AFB GA","state":"GA"},
    "KJKL":{"lat":37.591,"lon":-83.313,"name":"Jackson KY","state":"KY"},
    "KLBB":{"lat":33.654,"lon":-101.814,"name":"Lubbock TX","state":"TX"},
    "KLCH":{"lat":30.125,"lon":-93.216,"name":"Lake Charles LA","state":"LA"},
    "KLIX":{"lat":30.337,"lon":-89.826,"name":"New Orleans LA","state":"LA"},
    "KLNX":{"lat":41.958,"lon":-100.576,"name":"North Platte NE","state":"NE"},
    "KLOT":{"lat":41.604,"lon":-88.085,"name":"Chicago IL","state":"IL"},
    "KLRX":{"lat":40.740,"lon":-116.803,"name":"Elko NV","state":"NV"},
    "KLSX":{"lat":38.699,"lon":-90.683,"name":"St. Louis MO","state":"MO"},
    "KLTX":{"lat":33.989,"lon":-78.429,"name":"Wilmington NC","state":"NC"},
    "KLVX":{"lat":37.975,"lon":-85.944,"name":"Louisville KY","state":"KY"},
    "KLWX":{"lat":38.975,"lon":-77.478,"name":"Sterling VA","state":"VA"},
    "KLZK":{"lat":34.836,"lon":-92.262,"name":"Little Rock AR","state":"AR"},
    "KMAF":{"lat":31.943,"lon":-102.189,"name":"Midland/Odessa TX","state":"TX"},
    "KMAX":{"lat":42.081,"lon":-122.717,"name":"Medford OR","state":"OR"},
    "KMBX":{"lat":48.393,"lon":-100.864,"name":"Minot AFB ND","state":"ND"},
    "KMHX":{"lat":34.776,"lon":-76.876,"name":"Morehead City NC","state":"NC"},
    "KMKX":{"lat":42.968,"lon":-88.551,"name":"Milwaukee WI","state":"WI"},
    "KMLB":{"lat":28.113,"lon":-80.654,"name":"Melbourne FL","state":"FL"},
    "KMOB":{"lat":30.679,"lon":-88.240,"name":"Mobile AL","state":"AL"},
    "KMPX":{"lat":44.849,"lon":-93.565,"name":"Minneapolis MN","state":"MN"},
    "KMQT":{"lat":46.531,"lon":-87.548,"name":"Marquette MI","state":"MI"},
    "KMRX":{"lat":36.168,"lon":-83.402,"name":"Morristown TN","state":"TN"},
    "KMSX":{"lat":47.041,"lon":-113.986,"name":"Missoula MT","state":"MT"},
    "KMTX":{"lat":41.263,"lon":-112.448,"name":"Salt Lake City UT","state":"UT"},
    "KMUX":{"lat":37.155,"lon":-121.898,"name":"San Francisco CA","state":"CA"},
    "KMVX":{"lat":47.528,"lon":-97.325,"name":"Fargo ND","state":"ND"},
    "KMXX":{"lat":32.537,"lon":-85.790,"name":"Maxwell AFB AL","state":"AL"},
    "KNKX":{"lat":32.919,"lon":-117.042,"name":"San Diego CA","state":"CA"},
    "KNQA":{"lat":35.345,"lon":-89.873,"name":"Memphis TN","state":"TN"},
    "KOAX":{"lat":41.320,"lon":-96.367,"name":"Omaha NE","state":"NE"},
    "KOHX":{"lat":36.247,"lon":-86.563,"name":"Nashville TN","state":"TN"},
    "KOKX":{"lat":40.866,"lon":-72.864,"name":"New York NY","state":"NY"},
    "KOTX":{"lat":47.680,"lon":-117.627,"name":"Spokane WA","state":"WA"},
    "KPAH":{"lat":37.068,"lon":-88.772,"name":"Paducah KY","state":"KY"},
    "KPBZ":{"lat":40.532,"lon":-80.218,"name":"Pittsburgh PA","state":"PA"},
    "KPDT":{"lat":45.691,"lon":-118.853,"name":"Pendleton OR","state":"OR"},
    "KPOE":{"lat":31.156,"lon":-92.976,"name":"Fort Polk LA","state":"LA"},
    "KPUX":{"lat":38.460,"lon":-104.181,"name":"Pueblo CO","state":"CO"},
    "KRAX":{"lat":35.666,"lon":-78.490,"name":"Raleigh/Durham NC","state":"NC"},
    "KRGX":{"lat":39.754,"lon":-119.461,"name":"Reno NV","state":"NV"},
    "KRIW":{"lat":43.066,"lon":-108.477,"name":"Riverton WY","state":"WY"},
    "KRLX":{"lat":38.311,"lon":-81.723,"name":"Charleston WV","state":"WV"},
    "KRTX":{"lat":45.715,"lon":-122.965,"name":"Portland OR","state":"OR"},
    "KSFX":{"lat":43.106,"lon":-112.686,"name":"Pocatello ID","state":"ID"},
    "KSGF":{"lat":37.235,"lon":-93.401,"name":"Springfield MO","state":"MO"},
    "KSHV":{"lat":32.451,"lon":-93.841,"name":"Shreveport LA","state":"LA"},
    "KSJT":{"lat":31.371,"lon":-100.492,"name":"San Angelo TX","state":"TX"},
    "KSOX":{"lat":33.818,"lon":-117.636,"name":"Santa Ana Mtns CA","state":"CA"},
    "KSRX":{"lat":35.291,"lon":-94.362,"name":"Fort Smith AR","state":"AR"},
    "KTBW":{"lat":27.706,"lon":-82.402,"name":"Tampa FL","state":"FL"},
    "KTFX":{"lat":47.460,"lon":-111.386,"name":"Great Falls MT","state":"MT"},
    "KTLH":{"lat":30.398,"lon":-84.329,"name":"Tallahassee FL","state":"FL"},
    "KTLX":{"lat":35.333,"lon":-97.278,"name":"Oklahoma City OK","state":"OK"},
    "KTWX":{"lat":38.997,"lon":-96.233,"name":"Topeka KS","state":"KS"},
    "KTYX":{"lat":43.756,"lon":-75.680,"name":"Montague NY","state":"NY"},
    "KUDX":{"lat":44.125,"lon":-102.830,"name":"Rapid City SD","state":"SD"},
    "KUEX":{"lat":40.321,"lon":-98.442,"name":"Hastings NE","state":"NE"},
    "KVAX":{"lat":30.890,"lon":-83.002,"name":"Moody AFB GA","state":"GA"},
    "KVBX":{"lat":34.838,"lon":-120.398,"name":"Vandenberg AFB CA","state":"CA"},
    "KVNX":{"lat":36.741,"lon":-98.128,"name":"Vance AFB OK","state":"OK"},
    "KVTX":{"lat":34.412,"lon":-119.179,"name":"Los Angeles CA","state":"CA"},
    "KVWX":{"lat":38.260,"lon":-87.725,"name":"Evansville IN","state":"IN"},
    "KYUX":{"lat":32.495,"lon":-114.656,"name":"Yuma AZ","state":"AZ"},
    "PABC":{"lat":60.792,"lon":-161.876,"name":"Bethel AK","state":"AK"},
    "PACG":{"lat":56.853,"lon":-135.529,"name":"Sitka AK","state":"AK"},
    "PAEC":{"lat":64.511,"lon":-165.295,"name":"Nome AK","state":"AK"},
    "PAHG":{"lat":60.726,"lon":-150.974,"name":"Kenai AK","state":"AK"},
    "PAIH":{"lat":59.462,"lon":-146.301,"name":"Middleton Is AK","state":"AK"},
    "PAKC":{"lat":58.679,"lon":-156.629,"name":"King Salmon AK","state":"AK"},
    "PAPD":{"lat":65.035,"lon":-147.499,"name":"Fairbanks AK","state":"AK"},
    "PHKI":{"lat":21.894,"lon":-159.552,"name":"Kauai HI","state":"HI"},
    "PHKM":{"lat":20.126,"lon":-155.778,"name":"Kamuela HI","state":"HI"},
    "PHMO":{"lat":21.133,"lon":-157.180,"name":"Molokai HI","state":"HI"},
    "PHWA":{"lat":19.095,"lon":-155.569,"name":"South Shore HI","state":"HI"},
    "TJUA":{"lat":18.116,"lon":-66.078,"name":"San Juan PR","state":"PR"},
}

TILTS = [0.5,0.9,1.3,1.8,2.4,3.1,4.0,5.1,6.4,8.0,10.0,12.5,15.5,19.5]
BEAM_HEIGHTS = {
    0.5: [0.2,0.5,0.9,1.4,2.0,2.7,3.5,4.4,5.3,6.4,7.5],
    0.9: [0.3,0.8,1.5,2.4,3.4,4.6,5.9,7.4,9.0,10.7,12.5],
    1.3: [0.5,1.1,2.0,3.2,4.6,6.1,7.8,9.7,11.7,13.8,16.1],
    1.8: [0.6,1.5,2.7,4.1,5.8,7.7,9.8,12.0,14.4,16.9,19.5],
    2.4: [0.9,2.0,3.5,5.3,7.3,9.5,11.8,14.3,16.9,19.6,22.4],
    3.1: [1.1,2.5,4.4,6.6,9.1,11.8,14.8,17.9,21.2,24.7,28.3],
    4.0: [1.4,3.1,5.5,8.2,11.2,14.5,18.1,21.9,25.9,30.0,34.4],
    5.1: [1.8,4.0,7.0,10.4,14.2,18.4,22.8,27.5,32.4,37.5,42.8],
    6.4: [2.2,5.0,8.7,12.9,17.6,22.7,28.1,33.8,39.7,45.9,52.3],
    8.0: [2.8,6.3,10.9,16.1,21.9,28.2,34.8,41.8,49.0,56.5,64.3],
    10.0:[3.5,7.8,13.5,20.0,27.0,34.7,42.7,51.1,59.8,68.8,78.1],
    12.5:[4.3,9.7,16.7,24.6,33.1,42.4,52.1,62.2,72.6,83.4,94.5],
    15.5:[5.3,11.9,20.3,29.8,40.0,51.0,62.4,74.3,86.5,99.1,112.0],
    19.5:[6.9,14.2,22.9,32.4,42.2,52.3,62.5,72.8,83.2,93.7,104.2],
}

def _site_id(site):
    return (site or "").strip().upper()

def _scan_time_from_key(key):
    name = os.path.basename(key)
    m = re.match(r"([A-Z0-9]{4})(\d{8})_(\d{6})", name)
    if not m:
        return None
    dt = datetime.strptime(m.group(2) + m.group(3), "%Y%m%d%H%M%S")
    return dt.replace(tzinfo=timezone.utc)

def _format_scan_time(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC") if dt else ""

def _scan_record(key, size=0, last_modified=""):
    dt = _scan_time_from_key(key)
    filename = os.path.basename(key)
    return {
        "key": key,
        "filename": filename,
        "time": dt.strftime("%Y%m%d_%H%M%S") if dt else filename,
        "scan_time": _format_scan_time(dt),
        "iso_time": dt.isoformat() if dt else "",
        "size": int(size or 0),
        "last_modified": last_modified,
        "source": LEVEL2_BUCKET,
        "url": f"{LEVEL2_BASE_URL}/{urllib.parse.quote(key, safe='/')}",
    }

def _list_s3_prefix(prefix):
    scans = []
    token = None
    ns = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
    while True:
        params = {"list-type": "2", "prefix": prefix, "max-keys": "1000"}
        if token:
            params["continuation-token"] = token
        url = f"{LEVEL2_BASE_URL}/?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={"User-Agent": "VREM/0.5.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            root = ElementTree.fromstring(resp.read())
        for item in root.findall("s3:Contents", ns):
            key = item.findtext("s3:Key", default="", namespaces=ns)
            filename = os.path.basename(key)
            if not key or "_MDM" in filename:
                continue
            if not re.search(r"[A-Z0-9]{4}\d{8}_\d{6}", filename):
                continue
            size = item.findtext("s3:Size", default="0", namespaces=ns)
            last_modified = item.findtext("s3:LastModified", default="", namespaces=ns)
            scans.append(_scan_record(key, size, last_modified))
        next_token = root.findtext("s3:NextContinuationToken", default="", namespaces=ns)
        if not next_token:
            return scans
        token = next_token

def _recent_scan_dates():
    now = datetime.now(timezone.utc)
    return [now.date() - timedelta(days=i) for i in range(SCAN_LOOKBACK_DAYS)]

def _list_recent_scans(site, limit=MAX_SCANS):
    site = _site_id(site)
    scans = []
    for day in _recent_scan_dates():
        prefix = f"{day:%Y/%m/%d}/{site}/"
        try:
            scans.extend(_list_s3_prefix(prefix))
        except Exception as exc:
            print(f"VREM scan listing failed for {prefix}: {exc}")
    scans.sort(key=lambda s: s.get("iso_time") or s.get("key"), reverse=True)
    return scans[:limit]

def _latest_scan_for_site(site, force=False):
    site = _site_id(site)
    now = datetime.now(timezone.utc)
    cached = LATEST_SCAN_CACHE.get(site)
    if (
        cached
        and not force
        and (now - cached["timestamp"]).total_seconds() < LIVE_SCAN_CACHE_SECONDS
    ):
        return cached["scan"]
    scans = _list_recent_scans(site, limit=1)
    scan = scans[0] if scans else None
    LATEST_SCAN_CACHE[site] = {"timestamp": now, "scan": scan}
    return scan

def _cache_path_for_key(key):
    os.makedirs(LEVEL2_CACHE_DIR, exist_ok=True)
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
    return os.path.join(LEVEL2_CACHE_DIR, f"{digest}_{os.path.basename(key)}")

def _trim_level2_cache():
    try:
        files = [
            os.path.join(LEVEL2_CACHE_DIR, name)
            for name in os.listdir(LEVEL2_CACHE_DIR)
            if os.path.isfile(os.path.join(LEVEL2_CACHE_DIR, name))
        ]
    except FileNotFoundError:
        return
    files.sort(key=lambda path: os.path.getmtime(path), reverse=True)
    for old_path in files[MAX_CACHE_FILES:]:
        try:
            os.remove(old_path)
        except OSError:
            pass

def _download_scan(key):
    cache_path = _cache_path_for_key(key)
    if os.path.exists(cache_path) and os.path.getsize(cache_path) > 0:
        return cache_path
    url = f"{LEVEL2_BASE_URL}/{urllib.parse.quote(key, safe='/')}"
    req = urllib.request.Request(url, headers={"User-Agent": "VREM/0.5.0"})
    fd, tmp_path = tempfile.mkstemp(prefix="vrem_l2_", suffix=".tmp")
    os.close(fd)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp, open(tmp_path, "wb") as out:
            out.write(resp.read())
        os.replace(tmp_path, cache_path)
        _trim_level2_cache()
        return cache_path
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

def _field_value(moment, idx, default=None):
    if not moment:
        return default
    header, values = moment
    if idx >= len(values):
        return default
    value = values[idx]
    try:
        if value != value:
            return default
    except TypeError:
        return default
    return float(value)

def _moment(ray, *names):
    for name in names:
        found = ray.moments.get(name)
        if found:
            return found
    return None

def _beam_height_km(elevation_deg, range_km):
    el = math.radians(elevation_deg)
    re = EARTH_RADIUS_4_3_KM
    return math.sqrt((range_km * range_km) + (re * re) + (2 * range_km * re * math.sin(el))) - re

def _parse_level2_file(path, key, max_gates=None):
    from metpy.io import Level2File

    max_gates = int(max_gates or MAX_LIVE_GATES)
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        radar = Level2File(path)
    seed = int(hashlib.sha1(key.encode("utf-8")).hexdigest()[:8], 16)
    rng = random.Random(seed)
    gates = []
    seen = 0

    for sweep_idx, sweep in enumerate(radar.sweeps):
        if not sweep:
            continue
        ray_step = max(1, round(len(sweep) / 180))
        for ray in sweep[::ray_step]:
            header = ray.header
            ref_moment = _moment(ray, b"REF")
            if not ref_moment:
                continue
            vel_moment = _moment(ray, b"VEL", b"VR")
            zdr_moment = _moment(ray, b"ZDR")
            rho_moment = _moment(ray, b"RHO", b"CC")
            ref_header, ref_values = ref_moment
            gate_step = max(8, round(len(ref_values) / 180))
            az = math.radians(float(header.az_angle))
            el = float(header.el_angle)
            for gate_idx in range(0, len(ref_values), gate_step):
                ref = _field_value(ref_moment, gate_idx)
                if ref is None or ref < 5:
                    continue
                range_km = ref_header.first_gate + (gate_idx * ref_header.gate_width)
                if range_km > 460:
                    continue
                height_km = _beam_height_km(el, range_km)
                vel = _field_value(vel_moment, gate_idx, 0.0)
                zdr = _field_value(zdr_moment, gate_idx, 0.0)
                rho = _field_value(rho_moment, gate_idx, 0.99)
                gate = {
                    "x": round(math.sin(az) * range_km, 2),
                    "y": round(height_km, 3),
                    "z": round(math.cos(az) * range_km, 2),
                    "ref": round(ref, 1),
                    "vel": round(vel, 1),
                    "zdr": round(zdr, 2),
                    "rho": round(rho, 3),
                    "el": round(el, 2),
                    "ti": min(sweep_idx, len(TILTS) - 1),
                }
                seen += 1
                if len(gates) < max_gates:
                    gates.append(gate)
                else:
                    slot = rng.randrange(seen)
                    if slot < max_gates:
                        gates[slot] = gate

    gates.sort(key=lambda g: (g["ti"], g["el"], g["y"]))
    return gates

def _fallback_gates(site, key, max_gates=28000):
    seed = int(hashlib.sha1((site + key).encode("utf-8")).hexdigest()[:8], 16)
    rng = random.Random(seed)
    gates = []
    storm_radius = 160 + rng.random() * 220
    core_x = (rng.random() - 0.5) * 80
    core_z = (rng.random() - 0.5) * 80
    vrot = 20 + rng.random() * 55
    per_tilt = max(300, max_gates // len(TILTS))
    for ti, tilt in enumerate(TILTS):
        for _ in range(per_tilt):
            angle = rng.random() * math.tau
            radius = 15 + rng.random() * storm_radius
            hook = math.exp(-((angle - 4.5) ** 2) / 0.7) * (95 / (radius + 1))
            x = math.cos(angle + radius * 0.01) * radius + hook * 70
            z = math.sin(angle + radius * 0.01) * radius
            height = _beam_height_km(tilt, radius) + rng.random() * 0.5
            dist_core = math.hypot(x - core_x, z - core_z)
            intense_core = dist_core < 32 and height < 2.5
            rho = 0.42 + rng.random() * 0.28 if intense_core else 0.86 + rng.random() * 0.13
            ref = 62 + rng.random() * 12 if intense_core else max(5, 48 - dist_core * 0.08 + rng.random() * 24)
            vel = math.sin(angle) * vrot * math.exp(-dist_core / 180) + (rng.random() - 0.5) * 8
            gates.append({
                "x": round(x, 2), "y": round(height, 3), "z": round(z, 2),
                "ref": round(ref, 1), "vel": round(vel, 1),
                "zdr": round(max(-1, rng.random() * 4), 2),
                "rho": round(rho, 3), "el": tilt, "ti": ti,
            })
    return gates

def _request_gate_cap():
    raw = request.args.get("limit", "").strip()
    if raw == "":
        return MAX_LIVE_GATES
    try:
        value = int(raw)
    except ValueError:
        return MAX_LIVE_GATES
    if value <= 0:
        return 250000
    return max(1000, min(value, 250000))

def _level2_payload(site, scan, max_gates=None):
    max_gates = int(max_gates or MAX_LIVE_GATES)
    cache_id = f"{scan['key']}::{max_gates}"
    cached = PARSED_LEVEL2_CACHE.get(cache_id)
    if cached:
        return cached

    parse_error = None
    try:
        path = _download_scan(scan["key"])
        gates = _parse_level2_file(path, scan["key"], max_gates=max_gates)
    except Exception as exc:
        parse_error = str(exc)
        print(f"VREM Level II parse failed for {scan['key']}: {exc}")
        gates = _fallback_gates(site, scan["key"], max_gates=max_gates)

    payload = {
        "site": site,
        "source": LEVEL2_BUCKET if not parse_error else "metadata-fallback",
        "bucket": LEVEL2_BUCKET,
        "source_url": scan["url"],
        "key": scan["key"],
        "filename": scan["filename"],
        "scan_time": scan.get("scan_time") or _format_scan_time(_scan_time_from_key(scan["key"])),
        "count": len(gates),
        "gate_cap": max_gates,
        "parse_error": parse_error,
        "gates": gates,
    }
    PARSED_LEVEL2_CACHE[cache_id] = payload
    while len(PARSED_LEVEL2_CACHE) > 4:
        PARSED_LEVEL2_CACHE.pop(next(iter(PARSED_LEVEL2_CACHE)), None)
    return payload

def _alert_type(properties):
    event = properties.get("event", "")
    text = " ".join(str(properties.get(k, "")) for k in ("headline", "description", "instruction"))
    params = properties.get("parameters") or {}
    if params:
        text += " " + " ".join(" ".join(v) if isinstance(v, list) else str(v) for v in params.values())
    upper = text.upper().replace("-", " ")
    if event == "Tornado Warning" and "TORNADO EMERGENCY" in upper:
        return "TORE"
    return {
        "Tornado Warning": "TOR",
        "Severe Thunderstorm Warning": "SVR",
        "Flash Flood Warning": "FFW",
        "Tornado Watch": "TOR_WATCH",
        "Severe Thunderstorm Watch": "SVR_WATCH",
    }.get(event)

def _filtered_alert_feature(feature):
    props = feature.get("properties") or {}
    if props.get("event") not in ALERT_EVENTS:
        return None
    geometry = feature.get("geometry")
    if not geometry:
        return None
    alert_type = _alert_type(props)
    if not alert_type:
        return None
    keep_props = {
        "id": props.get("id") or feature.get("id"),
        "event": props.get("event"),
        "headline": props.get("headline") or props.get("event"),
        "areaDesc": props.get("areaDesc", ""),
        "severity": props.get("severity", ""),
        "certainty": props.get("certainty", ""),
        "urgency": props.get("urgency", ""),
        "sent": props.get("sent", ""),
        "effective": props.get("effective", ""),
        "expires": props.get("expires", ""),
        "ends": props.get("ends", ""),
        "description": props.get("description", ""),
        "instruction": props.get("instruction", ""),
        "vrem_type": alert_type,
    }
    return {"type": "Feature", "id": keep_props["id"], "geometry": geometry, "properties": keep_props}

def _active_alerts_payload():
    now = datetime.now(timezone.utc)
    if ALERT_CACHE["payload"] and ALERT_CACHE["timestamp"] and (now - ALERT_CACHE["timestamp"]).total_seconds() < 45:
        return ALERT_CACHE["payload"]
    req = urllib.request.Request(
        NWS_ALERTS_URL,
        headers={
            "User-Agent": "VREM/0.5.0 (local radar visualization)",
            "Accept": "application/geo+json, application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=12) as resp:
        raw = json.loads(resp.read().decode("utf-8"))
    features = []
    for feature in raw.get("features", []):
        filtered = _filtered_alert_feature(feature)
        if filtered:
            features.append(filtered)
    payload = {
        "type": "FeatureCollection",
        "source": "api.weather.gov",
        "updated": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "count": len(features),
        "features": features,
    }
    ALERT_CACHE["timestamp"] = now
    ALERT_CACHE["payload"] = payload
    return payload

def _validate_key_for_site(key, site):
    if not key:
        return False
    site = _site_id(site)
    m = re.match(r"^\d{4}/\d{2}/\d{2}/([A-Z0-9]{4})/[A-Z0-9]{4}\d{8}_\d{6}", key)
    return bool(m and m.group(1) == site and "_MDM" not in os.path.basename(key))

@app.after_request
def no_cache_api(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

@app.route('/')
def index(): return render_template('index.html')

@app.route('/api/health')
def health():
    return jsonify({
        "ok": True,
        "service": "VREM",
        "version": "0.5.0-beta",
        "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "radar_sites": len(WSR88D),
        "level2_bucket": LEVEL2_BUCKET,
        "max_scans": MAX_SCANS,
        "max_live_gates": MAX_LIVE_GATES,
        "runtime_settings": RUNTIME_SETTINGS,
    })

@app.route('/api/runtime-settings', methods=['GET', 'POST'])
def runtime_settings():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        if "suppress_terminal_warnings" in data:
            RUNTIME_SETTINGS["suppress_terminal_warnings"] = bool(data["suppress_terminal_warnings"])
        if "parser_verbosity" in data:
            verbosity = str(data["parser_verbosity"]).strip().lower()
            if verbosity in {"quiet", "normal", "verbose"}:
                RUNTIME_SETTINGS["parser_verbosity"] = verbosity
        _apply_runtime_logging_settings()
    return jsonify(RUNTIME_SETTINGS)

@app.route('/api/cache/clear', methods=['POST'])
def clear_cache():
    removed = 0
    try:
        for name in os.listdir(LEVEL2_CACHE_DIR):
            path = os.path.join(LEVEL2_CACHE_DIR, name)
            if os.path.isfile(path):
                os.remove(path)
                removed += 1
    except FileNotFoundError:
        pass
    PARSED_LEVEL2_CACHE.clear()
    LATEST_SCAN_CACHE.clear()
    return jsonify({"ok": True, "removed_files": removed})

@app.route('/api/radars')
def get_radars(): return jsonify(WSR88D)

@app.route('/api/config')
def get_config(): return jsonify({'tilts':TILTS,'beam_heights':BEAM_HEIGHTS,'max_range_km':460})

@app.route('/api/scans/<site>')
def get_scans(site):
    return jsonify({
        "error": "Past scan selection has been removed in VREM 0.5.0 Beta.",
        "live_endpoint": f"/api/live/{_site_id(site)}",
    }), 410

@app.route('/api/level2/<site>')
def get_level2(site):
    site = _site_id(site)
    if site not in WSR88D:
        return jsonify({"error": "Unknown radar site"}), 404

    key = request.args.get("key", "").strip()
    if key:
        return jsonify({
            "error": "Loading older scan keys has been removed. Use the live endpoint for the newest scan.",
            "live_endpoint": f"/api/live/{site}",
        }), 410

    scan = _latest_scan_for_site(site)
    if not scan:
        return jsonify({"error": "No recent Level II scans available", "site": site, "source": LEVEL2_BUCKET}), 404

    return jsonify(_level2_payload(site, scan, max_gates=_request_gate_cap()))

@app.route('/api/live/<site>')
def get_live_level2(site):
    site = _site_id(site)
    if site not in WSR88D:
        return jsonify({"error": "Unknown radar site"}), 404
    scan = _latest_scan_for_site(site)
    if not scan:
        return jsonify({"error": "No recent Level II scans available", "site": site, "source": LEVEL2_BUCKET}), 404
    since = request.args.get("since", "").strip()
    gate_cap = _request_gate_cap()
    if since and since == scan["key"]:
        return jsonify({
            "site": site,
            "unchanged": True,
            "key": scan["key"],
            "filename": scan["filename"],
            "scan_time": scan.get("scan_time") or _format_scan_time(_scan_time_from_key(scan["key"])),
            "gate_cap": gate_cap,
            "next_refresh_seconds": LIVE_REFRESH_SECONDS,
        })
    payload = dict(_level2_payload(site, scan, max_gates=gate_cap))
    payload["unchanged"] = False
    payload["next_refresh_seconds"] = LIVE_REFRESH_SECONDS
    return jsonify(payload)

@app.route('/api/alerts')
def get_alerts():
    try:
        return jsonify(_active_alerts_payload())
    except Exception as exc:
        return jsonify({"type": "FeatureCollection", "source": "api.weather.gov", "error": str(exc), "count": 0, "features": []}), 502

@app.route('/api/proxy')
def proxy():
    url = request.args.get('url','')
    allowed = ('https://mesonet.agron.iastate.edu','https://radar.weather.gov',
                LEVEL2_BASE_URL,
                'https://server.arcgisonline.com','https://services.arcgisonline.com',
                'https://api.weather.gov','https://openlayers.org')
    if not any(url.startswith(a) for a in allowed): return 'Forbidden',403
    try:
        req = urllib.request.Request(url,headers={'User-Agent':'VREM/1.0'})
        with urllib.request.urlopen(req,timeout=12) as r:
            data=r.read(); ct=r.headers.get('Content-Type','application/octet-stream')
        return Response(data,content_type=ct)
    except Exception as e: return str(e),500

def run():
    display_host = "localhost" if APP_HOST in {"0.0.0.0", "127.0.0.1"} else APP_HOST
    print("=" * 55)
    print(f"  VREM 0.5.0 Beta · http://{display_host}:{APP_PORT}")
    print(f"  Level II source · {LEVEL2_BUCKET}")
    print("=" * 55)
    try:
        from waitress import serve
    except Exception:
        print("  Waitress not installed; falling back to Flask development server.")
        app.run(host=APP_HOST, port=APP_PORT, debug=APP_DEBUG, threaded=True)
        return
    serve(app, host=APP_HOST, port=APP_PORT, threads=APP_THREADS)

if __name__=='__main__':
    run()
