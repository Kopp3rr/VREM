@echo off
setlocal EnableExtensions
cd /d "%~dp0.VREM"
call VREM.bat
