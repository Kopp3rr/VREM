@echo off
setlocal EnableExtensions
title VREM 0.5.0 Beta
color 0C

cd /d "%~dp0"

echo.
echo  VREM 0.5.0 Beta
echo  Volumetric Radar Echo Map
echo  -------------------------------------------------------
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python was not found on PATH.
    echo  Install Python 3.11+ from python.org and enable "Add python.exe to PATH".
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo  Creating local Python environment...
    python -m venv .venv
    if errorlevel 1 (
        echo  [ERROR] Could not create the local Python environment.
        pause
        exit /b 1
    )
)

echo  Installing/verifying dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo  [ERROR] Dependency installation failed.
    pause
    exit /b 1
)

for /f %%P in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "5000..5010 | Where-Object { -not (Get-NetTCPConnection -LocalPort $_ -State Listen -ErrorAction SilentlyContinue) } | Select-Object -First 1"') do set VREM_PORT=%%P
if "%VREM_PORT%"=="" set VREM_PORT=5000

set VREM_HOST=127.0.0.1
set VREM_ENV=production
set VREM_MAX_SCANS=32
set VREM_MAX_LIVE_GATES=65000
set VREM_MAX_CACHE_FILES=96

echo.
echo  Starting VREM at http://localhost:%VREM_PORT%
echo  Close this window to stop the server.
echo  -------------------------------------------------------
echo.

start "" "http://localhost:%VREM_PORT%"
".venv\Scripts\python.exe" app.py

pause
