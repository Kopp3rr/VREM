#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

find_free_port() {
  local port
  for port in {5000..5010}; do
    if command -v ss >/dev/null 2>&1; then
      if ! ss -ltn | awk '{print $4}' | grep -Eq "[:.]${port}$"; then
        echo "$port"
        return 0
      fi
    elif command -v lsof >/dev/null 2>&1; then
      if ! lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1; then
        echo "$port"
        return 0
      fi
    else
      echo "$port"
      return 0
    fi
  done
  echo "5000"
}

echo
echo " VREM 0.5.0 Beta"
echo " Volumetric Radar Echo Map"
echo " -------------------------------------------------------"
echo

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo " [ERROR] python3 was not found on PATH."
  exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo " Creating local Python environment..."
  if ! "$PYTHON_BIN" -m venv .venv; then
    echo " [ERROR] Could not create the local Python environment."
    echo " On Ubuntu/Debian, install python3-venv, then run this script again."
    exit 1
  fi
fi

echo " Installing/verifying dependencies..."
".venv/bin/python" -m pip install --upgrade pip --quiet
".venv/bin/python" -m pip install -r requirements.txt --quiet

export VREM_HOST="${VREM_HOST:-127.0.0.1}"
export VREM_PORT="${VREM_PORT:-$(find_free_port)}"
export VREM_ENV="${VREM_ENV:-production}"
export VREM_MAX_SCANS="${VREM_MAX_SCANS:-32}"
export VREM_MAX_LIVE_GATES="${VREM_MAX_LIVE_GATES:-65000}"
export VREM_MAX_CACHE_FILES="${VREM_MAX_CACHE_FILES:-96}"

URL="http://localhost:${VREM_PORT}"
echo
echo " Starting VREM at ${URL}"
echo " Press Ctrl+C to stop the server."
echo " -------------------------------------------------------"
echo

if command -v open >/dev/null 2>&1; then
  open "$URL" >/dev/null 2>&1 &
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1 &
fi

exec ".venv/bin/python" app.py
